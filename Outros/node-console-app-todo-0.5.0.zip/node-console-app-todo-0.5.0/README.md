# Aplicación de consola interactiva

Esta aplicación es parte de mi curso de Node de cero a experto que puedes encontrar aquí:

[Node: De cero a experto](https://fernando-herrera.com/#/curso/node-cero-experto)

