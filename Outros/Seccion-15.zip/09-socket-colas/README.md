# Socket Server Basico

Un servidor de Websockets usando Node, Express y Socket.io

Temas cubiertos en mi curso de Node de cero a experto
