# Aplicación de Clima

Recuerden reconstruir los módulos de node con el comando
```npm init```

# Nota:
Esto es parte de mi curso de Node:

[Node de cero a experto](https://fernando-herrera.com/#/curso/node-cero-experto)